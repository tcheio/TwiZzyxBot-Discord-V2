module.exports = {
    clients: {
        token: 'MTAyMjQyMjg1NDYzMDkwMzg2OA.GoaYvi.YnutKbkwHfb5Rim_d9dyYM5M4GlJkB6dtHkygQ',
        name: 'TwiZzyx Bot',
        logo: 'https://zupimages.net/up/22/49/c838.png',
    }
}