module.exports = {
    clients: {
        token: 'MTAyMjQyMjg1NDYzMDkwMzg2OA.GdIibY.uof6ivodN-G_n4SfTivJ8-KbPDIK19M_y2RSR8',
        name: 'TwiZzyx Bot',
        logo: 'https://zupimages.net/up/22/49/c838.png',
    }
}