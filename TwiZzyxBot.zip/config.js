module.exports = {
    clients: {
        token: 'MTA0MTYyNTU4NjY0MjIwMjYzNA.GyN6Bb.HjUD1Pl5pe7AutdyUwAHT3sYNczFk0rx5YriU0',
        name: 'TwiZzyx Bot',
        logo: 'https://zupimages.net/up/22/49/c838.png',
    }
}