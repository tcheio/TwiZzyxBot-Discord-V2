module.exports = {
    clients: {
        clientId: '209395375474212865',
        token: 'MTA0MTYyNTU4NjY0MjIwMjYzNA.GScRe8.tQYvZTFCSXy0gUkIptjAx-oqYYfd90RtrEPcaU',
        name: 'TwiZzyx Bot',
        logo: 'https://zupimages.net/up/22/49/c838.png',
    },

    channel: {
        //Channel Discord Final
        stream: '748855744274890772',
        videos: '748247106980020236',
        tiktok: '892842982112374804',
        clip: '892842982112374804',
        lp: '1023891712403312720',

        reping: '1145793877685588019',
        titre: '1064817596261728356',
        generalStaff: '749975416944721940',
        log: '1060946019333976204',

        //Channel Discord Test
        chainePrincipal: '1104368803523072010',
        youtube: '1061410003300397066',
        twitch: '1061413496564219926',
        short: '1145837369191317544',

        //Channel de Test
        envoie: '1096735287561965568',
        retour: '1096735321456136222',
        logTest: '1097913354296774738',
        start: '1133295124307255327',

}}