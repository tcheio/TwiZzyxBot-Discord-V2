class PlanningControlleur{

    constructor(lien){
        this.lien = lien;
        }

    getLien() {
        return this.lien;
    }
    
}