module.exports = {
    clients: {
        clientId: '209395375474212865',
        token: 'MTAyMjQyMjg1NDYzMDkwMzg2OA.GixooE.FiVeqmU0HyovsOj06TMIl8gQGFvsTMDPHyAN5I',
        name: 'TwiZzyx Bot',
        logo: 'https://media.discordapp.net/attachments/1064189139349684244/1064189177060663326/channels4_profile.jpg?ex=65bf9ee7&is=65ad29e7&hm=bdcc8723e911ab1db59d8c671bd32bf85f81842cfb7db4460aaf68ddb75bacc5&=&format=webp&width=671&height=671',
        tokenTest: 'MTA0MTYyNTU4NjY0MjIwMjYzNA.Gc-NMa.Y9D5w3PaQ9k8MCKLN-VQ42d1zItLxSgO_H3RDw'
    },

    channel: {
        //Channel Discord Final
        stream: '748855744274890772',
        videos: '748247106980020236',
        tiktok: '892842982112374804',
        clip: '892842982112374804',
        replay: '1023891712403312720',

        reping: '1145793877685588019',
        titre: '1064817596261728356',
        generalStaff: '749975416944721940',
        log: '1060946019333976204',

        //Channel Discord Test
        chainePrincipal: '1104368803523072010',
        twizzyx2: '1061410003300397066',
        twizzyxReplay: '1197099994033963058',
        twitch: '1061413496564219926',
        short: '1145837369191317544',

        //Channel de Test
        envoie: '1096735287561965568',
        envoie2: '1134145945232224397',
        envoie3: '1197103814419943525',
        retour: '1096735321456136222',
        logTest: '1097913354296774738',
        start: '1133295124307255327',

    },

    Info:{
        OwnerID: '209395375474212865',
    }

}