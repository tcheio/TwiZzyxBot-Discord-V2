module.exports = {
    clients: {
        clientId: '209395375474212865',
        token: 'MTAyMjQyMjg1NDYzMDkwMzg2OA.GVGHdD.jJhsC0MlQjDWYI89TIBeogoNmPkvLAfhp9vd1I',
        name: 'TwiZzyx Bot',
        logo: 'https://zupimages.net/up/22/49/c838.png',
    },

    channel: {
        //Channel Discord Final
        stream: '748855744274890772',
        videos: '748247106980020236',
        tiktok: '892842982112374804',
        clipytb: '1014439891297386516',
        lp: '1023891712403312720',

        reping: '1116320116322336870',
        titre: '1064817596261728356',
        generalStaff: '749975416944721940',
        log: '1060946019333976204',

        //Channel Discord Test
        chainePrincipal: '1104368803523072010',
        youtube: '1061410003300397066',
        twitch: '1061413496564219926',
        tiktokT: '1079743531603730472',

        //Channel de Test
        envoie: '1096735287561965568',
        retour: '1096735321456136222',
        logTest: '1097913354296774738',
        start: '1133295124307255327',

}}