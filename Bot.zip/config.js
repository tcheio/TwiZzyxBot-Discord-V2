module.exports = {
    clients: {
        token: 'MTA0MTYyNTU4NjY0MjIwMjYzNA.GAm-CB.OZjhvQIlb3zRGRZZ8tch_N23Ff551pCKiduTP8',
        name: 'TwiZzyx Bot',
        logo: 'https://zupimages.net/up/22/49/c838.png',
    }
}