module.exports = {
    clients: {
        token: 'MTA0MTYyNTU4NjY0MjIwMjYzNA.GHJnQC.EObd-p8WFJQYZ_6ghOMPA_1DtlPPwT0i6bErns',
        name: 'TwiZzyx Bot',
        logo: 'https://zupimages.net/up/22/49/c838.png',
    }
}