module.exports = {
    clients: {
        token: 'MTA0MTYyNTU4NjY0MjIwMjYzNA.GktlmN.SaWUldytGv3xiGA_lCI961bEk1gsBmevDPvxnk',
        name: 'TwiZzyx Bot',
        logo: 'https://zupimages.net/up/22/49/c838.png',
    }
}